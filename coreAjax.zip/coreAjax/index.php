<!DOCTYPE html>
<html>
<head>
	<title>---CodeIgnitor---</title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
	<script>
		$(document).ready(function()
		{
			$('#add').click(function(e)
			{
				e.preventDefault();
				var form = $('form')[0];
				var formData = new FormData(form);
				$.ajax(
				{
					type: "POST",
					url : "insert.php",
					cache :false,
					contentType :false,
					processData:false,
					data:formData,
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"select.php",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});

		$(function()
		{
			$('#upd').click(function(e)
			{
				e.preventDefault();
				$('#add').show();
				$('#upd').hide();
				var form = $('form')[0];
				var formData= new FormData(form);
				$.ajax(
				{
					type:"POST",
					url:"update.php",
					data:formData,
					cache :false,
					contentType :false,
					processData:false,
					data:formData,
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"select.php",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
	</script>
</head>
<body>
<br><br>
	
	<form method="POST" enctype="multipart/form-data">
		<div align="center">
			<h1>-----  CodeIgnitor  -----</h1>
		</div>
		<table border="2" align="center">
		<input type="text" name="uid" id="uid" hidden="">
			<tr>
				<th colspan="2" align="center">Insert Form</th>
			</tr>
			<tr>
				<th>First name :</th>
				<td>
					<input type="text" name="fname" id="fname">
				</td>
			</tr>
			<tr>
				<th>Last name :</th>
				<td>
					<input type="text" name="lname" id="lname">
				</td>
			</tr>
			<tr>
				<th>Gender : </th>
				<td>
					<input type="radio" name="gender" id="gender" value="Male">Male
					<input type="radio" name="gender" id="gender" value="Female">Female
				</td>
			</tr>
			<tr>
				<th>Education : </th>
				<td>
					<select name="education" id="education">
						<option value="null">---Select Education---</option>
						<option value="BCA">BCA</option>
						<option value="MCA">MCA</option>
						<option value="BBA">BBA</option>
					</select>
				</td>
			</tr>
			<tr>
				<th>Hobby : </th>
				<td>
					<input type="checkbox" name="hobby[]" id="cricket" value="cricket">Cricket
					<input type="checkbox" name="hobby[]" id="music" value="music">Music
					<input type="checkbox" name="hobby[]" id="dance" value="dance">Dance
				</td>
			</tr>
			<tr>
				<th>Profile : </th>
				<td>
					<input type="file" name="profile">
					<div id="pro"></div>
				</td>
			</tr>
			<tr>
				<th>Gallery : </th>
				<td>
					<input type="file" name="gallery[]" multiple="">
					<div id="gallery"></div>
				</td>
			</tr>
			<tr>
				<td align="center" colspan="2">	
					<input type="submit" name="submit" id="add" value="Insert">
					<input type="submit" name="update" id="upd" value="Update" hidden="" >
				</td>
			</tr>			
		</table>

	</form>
	<div id="view"></div>

</body>
</html>